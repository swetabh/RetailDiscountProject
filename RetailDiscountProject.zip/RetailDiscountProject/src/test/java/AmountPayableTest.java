import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import retail.AmountPayable;

/**
 * 
 * @author swetabh
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class AmountPayableTest {

	@InjectMocks
    AmountPayable masterController;

	@BeforeClass
	public static void initData() {
	}

	@Before
	public void beforeEachTest() {
	}

	@Test
	public void testCalcAmountEmployeeSuccess() throws Exception {

		String userType = "Employee";
		BigDecimal amount = masterController.calcPayableAmount(userType);
		assertEquals(amount, BigDecimal.valueOf(581));
	}
	
	@Test
	public void testCalcAmountAffiliateSuccess() throws Exception {

		String userType = "Affiliate";
		BigDecimal amount = masterController.calcPayableAmount(userType);
		assertEquals(amount, BigDecimal.valueOf(747));
	}

	@Test
	public void testCalcAmountCustomerSuccess() throws Exception {

		String userType = "Customer";
		BigDecimal amount = masterController.calcPayableAmount(userType);
		assertEquals(amount, BigDecimal.valueOf(788.5));
	}

	@Test
	public void testCalcAmountDefaultUserSuccess() throws Exception {

		String userType = "DefaultUser";
		BigDecimal amount = masterController.calcPayableAmount(userType);
		assertEquals(amount, BigDecimal.valueOf(830));
	}
	
}