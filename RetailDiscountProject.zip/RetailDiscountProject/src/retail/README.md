Assumptions :
1.> User can either be an employee, affiliate or a customer but can not have more than one role at a time.(One to One mapping with Role)
2.> The person will know before calculation what is the type of user (Employee, Affiliate or Customer)
3.> At a time, only one kind of orders will come (Either Employee, customer or Affiliate)

Note: In order to run the project, kindly download the source code and run the AmountPayable class. I have kept it as a simple stand alone application in order to run the calculation easily. We can add the spring boot and other spring modules to the application. I did not add more code(Check user is older than 2 years etc.) due to the time constraint.